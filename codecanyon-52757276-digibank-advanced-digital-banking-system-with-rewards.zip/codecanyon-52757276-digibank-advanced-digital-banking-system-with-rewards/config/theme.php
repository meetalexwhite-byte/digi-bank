<?php

return [
    'active' => 'default',
];
