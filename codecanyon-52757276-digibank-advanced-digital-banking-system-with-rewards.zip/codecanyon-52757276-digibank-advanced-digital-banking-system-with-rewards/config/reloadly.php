<?php

return [
    'connections' => [
        'client_id' => '',
        'client_secret' => '',
        'grant_type' => 'client_credentials',
        'live_or_sandbox_url' => '',
    ],
];
