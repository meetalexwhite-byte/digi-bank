<?php

return [
    'connections' => [
        'secret_key' => '',
    ],
];
