<?php

return [
    'connections' => [
        'api_key' => '',
        'api_token' => '',
    ],
];
