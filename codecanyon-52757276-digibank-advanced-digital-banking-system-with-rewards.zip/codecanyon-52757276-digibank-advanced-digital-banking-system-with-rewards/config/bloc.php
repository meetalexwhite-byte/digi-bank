<?php

return [
    'connections' => [
        'api_key' => '',
    ],
];
