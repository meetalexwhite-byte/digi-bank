<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;

class HistoryController extends Controller
{
    //
}
